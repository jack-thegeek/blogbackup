 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>技术</title>
	 <style type="text/css">
	.menu a:link,a:visited{
			text-decoration:none;
			color: white;
	}
	a:hover{color: yellow;font-weight:bold;font-size: 105%;}
	.menu div:hover{}

	.header ul{display: inline-block;}
	.header{
		background-color: #fcfcfc;
		display: inline-block;
		margin:0 auto;
		height: 150px;
		width: 100%;
	}
	.bar{
		display: inline-block;
		height: 120px;
		width: 900px;
	}
	.logo2{display: inline-block;font-size: 35px;color: #465D4C;}
	.menu{
		background-color: #7DB9DE;
		font-size: 20px;
		height: 30px;
		width: 100%;
		text-align: left;
	}
	.menu ul{
	
	display: inline-block;
	list-style: none;
	margin: 0px;
	}

	.menu ul li{float: left;margin: 0 30px;}

	.body{
	margin:0 auto;
	width: 900px;
	height: 600px;
	/*background: #7DB9DE;-*/
	}
	.log{
		margin: 0 auto;
		width: 600px;
		<!-- background-color: #A8D8B9; -->
	}
	.explain{
		line-height: 30px;
		margin-top: 30px;
		width: 100%;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        text-align: left;
        float: left;
        margin-bottom: 20px;
        padding: 10px;
        padding-top: 5px;
	}
	.cardBox {
		line-height: 30px;
        width: 600px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        text-align: left;
        float: left;
        margin-top: 20px;
        margin-bottom: 20px;
        padding: 30px;
        padding-top: 15px;
     }
	 </style>
</head>

<body>
	
	<div class="header">
		<div class="bar">
			<div class="logo">
				<img src="https://ae01.alicdn.com/kf/HTB1Qd4FU4TpK1RjSZFKq6y2wXXav.jpg" height="120" style="left:10%;position: absolute;">
			</div>
			<div class="logo2">
				<p style="right: 10%;position: absolute;">
					无名小站
				</p>
			</div>
			
		</div>
		<div class="menu">
				<ul>
				<li><a href="index.php">主页</a></li>
				<li><a href="books.php">书籍</a></li>
				<li><a href="technology.php">技术</a></li>
				<li><a href="software.php">软件</a></li>
				<li><a href="magic.php">魔方</a></li>
				<li><a href="mixed.php">杂七杂八</a></li>
				</ul>
		</div>
	</div>
	<div class="body">
		 
		 <div class="explain">
		 	<p>一切源于没钱。</p>
		 	<p>初二暑假买了属于自己的第一部手机，如果不是当时想卸载掉内置推广软件，就不会接触到root权限，那这辈子就与刷机这个词无缘，后来也就不会认识尹子玮与魏秉熙，也不会被某人叫了几年技术宅。那时谷歌还可以靠改hosts访问，从root到刷机，有过很多误打误撞的成功，也有过刷坏字库的惨痛，开始是为了优化，乐在其中，后来就着了魔似的，单单为了刷机而刷机。</p>
		 	<p>高中买到第一台电脑，因为贵，开始不敢乱搞，尽管觉得他跟手机一样。现在想来只觉得好笑，其实电脑比手机安全多了。看着教程，也踏上了折腾电脑的不归路。</p>
		 	<p>好久没刷机，以为自己真的老了，对这些没兴趣了，谁知买了部小米的机子，又出了面具这样的神器，解锁换rec刷谷歌服务装面具改build，又开始了无穷尽的折腾，趁还年轻，多折腾下吧。</p>
		 	<p>所以这个板块，会有实用的电脑技巧，也有解决某些问题的个人笔记。</p>
		 </div>
	 	
	</div>

    
</body>

</html>