 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>主页</title>
	 <style type="text/css">
	.menu a:link,a:visited{
			text-decoration:none;
			color: white;
	}
	a:hover{color: yellow;font-weight:bold;font-size: 105%;}
	.menu div:hover{}

	.header ul{display: inline-block;}
	.header{
		background-color: #fcfcfc;
		display: inline-block;
		margin:0 auto;
		height: 150px;
		width: 100%;
	}
	.bar{
		display: inline-block;
		height: 120px;
		width: 900px;
	}
	/*.logo{
		background-image: url('https://ae01.alicdn.com/kf/HTB1Qd4FU4TpK1RjSZFKq6y2wXXav.jpg');
		height: 120px;
		width: 120px;
		background-position: 0 0;
		display: inline-block;
		background-repeat: no-repeat;
		left: 10%;
		position: absolute;
		
	}*/
	.logo2{display: inline-block;font-size: 35px;color: #465D4C;}
	.menu{
		background-color: #7DB9DE;
		font-size: 20px;
		height: 30px;
		width: 100%;
		text-align: left;
	}
	.menu ul{
	
	display: inline-block;
	list-style: none;
	margin: 0px;
	}

	.menu ul li{float: left;margin: 0 30px;}

	.body{
	margin:0 auto;
	width: 900px;
	height: 800px;
	/*background: #7DB9DE;-*/
	}
	.log{
		margin: 0 auto;
		width: 600px;
		/* background-color: #A8D8B9; */
	}
	.cardBox {
		line-height: 30px;
        width: 600px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        text-align: left;
        float: left;
        margin-top: 20px;
        margin-bottom: 20px;
        padding: 30px;
        padding-top: 15px;
            }
	 </style>
</head>

<body>
	
	<div class="header">
		<div class="bar">
			<div class="logo">
				<img src="https://ae01.alicdn.com/kf/HTB1Qd4FU4TpK1RjSZFKq6y2wXXav.jpg" height="120" style="left:10%;position: absolute;">
			</div>
			<div class="logo2">
				<p style="right: 10%;position: absolute;">无名小站</p>
			</div>
			
		</div>
		<div class="menu">
				<ul>
				<li><a href="index.php">主页</a></li>
				<li><a href="books.php">书籍</a></li>
				<li><a href="technology.php">技术</a></li>
				<li><a href="software.php">软件</a></li>
				<li><a href="magic.php">魔方</a></li>
				<li><a href="mixed.php">杂七杂八</a></li>
				</ul>
		</div>
	</div>
	<div class="body">
			<div class="log"><p style="text-align: center;color: #A8A8A8;font-size: 20px;margin-bottom: 0px;">更新日志</p></div>
		 <div class="log">
		 	
		 	<div class="cardBox" style="margin-top: 60px;">
		 		<p style="text-align: center;font-size: 25px;margin-bottom: 0px;">html的坑</p>
			 	<p style="color: #A8A8A8;text-align: center;">2019-5-10</p>
				 <p>稍微懂点计算机的，包括现在的我，都认为html算不上是计算机语言，因为里面的东西基本就是英语单词，直白易懂。但是永远不要小看它，其实html的坑非常多，各种难以清除的浮动，如果要兼容不同的浏览器内核，那就更加复杂。这也是拖到这么晚的原因，本来想加个鼠标移动到小蓝身上会变成另外一个图的效果，但是用上background一片灰色，排查半天还是放弃了。后面一定补上。
				</p>
		 	</div>
		 	<div class="cardBox">
		 		<p style="text-align: center;font-size: 25px;margin-bottom: 0px;">还没有名字的网站</p>
			 	<p style="color: #A8A8A8;text-align: center;">2019-5-10</p>
			 	<p>
			 		花了点时间，终于把这个简陋的网站做出来了。其实高三就有这个想法，做个个人网站，想分享一些软件，以及所谓的技术教程。当时甚至连基本的板块都设计好了，只是高考后心情很差，也就没那兴致了。
			 	</p>
				 <p>
				 	直接原因是，实验课上看到学霸在注册新浪云，当时我看懂了，晚上回到宿舍便开始尝试。本来用WordPress这样的系统建站，会好看很多，功能也会更多；或者直接套模板，也会有不错的效果。但是吧，大一自学了一点的html&PHP不用白不用（现在只是纯html），界面将就着看吧，尤其这学期课程多而难，美化怕是会搁很久。未来会慢慢把留言等功能加上（挖了个大坑）。
				 </p>
				 <p>
				 	日志与简介中可能会出现大家的名字，希望不要介意，因为能看到这个网站的你们，都是我很好的朋友。
				 </p><p>算是缘起。</p>
		 	</div>
		 </div>
	</div>

    
</body>

</html>