 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>软件</title>
	 <style type="text/css">
	.menu a:link,a:visited{
			text-decoration:none;
			color: white;
	}
	a:hover{color: yellow;font-weight:bold;font-size: 105%;}
	.menu div:hover{}

	.header ul{display: inline-block;}
	.header{
		background-color: #fcfcfc;
		display: inline-block;
		margin:0 auto;
		height: 150px;
		width: 100%;
	}
	.bar{
		display: inline-block;
		height: 120px;
		width: 900px;
	}
	.logo2{display: inline-block;font-size: 35px;color: #465D4C;}
	.menu{
		background-color: #7DB9DE;
		font-size: 20px;
		height: 30px;
		width: 100%;
		text-align: left;
	}
	.menu ul{
	
	display: inline-block;
	list-style: none;
	margin: 0px;
	}

	.menu ul li{float: left;margin: 0 30px;}

	.body{
	margin:0 auto;
	width: 900px;
	height: 600px;
	/*background: #7DB9DE;-*/
	}
	.log{
		margin: 0 auto;
		width: 600px;
		<!-- background-color: #A8D8B9; -->
	}
		.explain{
		line-height: 30px;
		margin-top: 30px;
		width: 100%;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        text-align: left;
        float: left;
        margin-bottom: 20px;
        padding: 10px;
        padding-top: 5px;
	}
	.cardBox {
		line-height: 30px;
        width: 600px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        text-align: left;
        float: left;
        margin-top: 20px;
        margin-bottom: 20px;
        padding: 30px;
        padding-top: 15px;
     }
	 </style>
</head>

<body>
	
	<div class="header">
		<div class="bar">
			<div class="logo">
				<img src="https://ae01.alicdn.com/kf/HTB1Qd4FU4TpK1RjSZFKq6y2wXXav.jpg" height="120" style="left:10%;position: absolute;">
			</div>
			<div class="logo2">
				<p style="right: 10%;position: absolute;">
					无名小站
				</p>
			</div>
			
		</div>
		<div class="menu">
				<ul>
				<li><a href="index.php">主页</a></li>
				<li><a href="books.php">书籍</a></li>
				<li><a href="technology.php">技术</a></li>
				<li><a href="software.php">软件</a></li>
				<li><a href="magic.php">魔方</a></li>
				<li><a href="mixed.php">杂七杂八</a></li>
				</ul>
		</div>
	</div>
	<div class="body">
		<div class="explain">
			<p>	不知道现在盗版Windows系统在中国泛滥到什么程度，反正就这样用吧。主要放些破解精简的软件，有安卓，也有Windows的，能被我放上来的，都是佳软。</p>
		</div>
	</div>

    
</body>

</html>