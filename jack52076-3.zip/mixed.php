 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>杂七杂八</title>
	 <style type="text/css">
	.menu a:link,a:visited{
			text-decoration:none;
			color: white;
	}
	a:hover{color: yellow;font-weight:bold;font-size: 105%;}
	.menu div:hover{}

	.header ul{display: inline-block;}
	.header{
		background-color: #fcfcfc;
		display: inline-block;
		margin:0 auto;
		height: 150px;
		width: 100%;
	}
	.bar{
		display: inline-block;
		height: 120px;
		width: 900px;
	}
	.logo2{display: inline-block;font-size: 35px;color: #465D4C;}
	.menu{
		background-color: #7DB9DE;
		font-size: 20px;
		height: 30px;
		width: 100%;
		text-align: left;
	}
	.menu ul{
	
	display: inline-block;
	list-style: none;
	margin: 0px;
	}

	.menu ul li{float: left;margin: 0 30px;}

	.body{
	margin:0 auto;
	width: 900px;
	height: 600px;
	/*background: #7DB9DE;-*/
	}
	.log{
		margin: 0 auto;
		width: 600px;
	}
	.explain{
		margin-top: 0;
		width: 100%;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        text-align: right;
        float: left;
        margin-top: 0px;
        margin-bottom: 20px;
        padding: 10px;
        padding-top: 5px;
	}
	.cardBox {
		line-height: 30px;
        width: 600px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        text-align: left;
        float: left;
        margin-top: 20px;
        margin-bottom: 20px;
        padding: 30px;
        padding-top: 15px;
     }
	 </style>
</head>

<body>
	
	<div class="header">
		<div class="bar">
			<div class="logo">
				<img src="https://ae01.alicdn.com/kf/HTB1Qd4FU4TpK1RjSZFKq6y2wXXav.jpg" height="120" style="left:10%;position: absolute;">
			</div>
			<div class="logo2">
				<p style="right: 10%;position: absolute;">
					无名小站
				</p>
			</div>
			
		</div>
		<div class="menu">
				<ul>
				<li><a href="index.php">主页</a></li>
				<li><a href="books.php">书籍</a></li>
				<li><a href="technology.php">技术</a></li>
				<li><a href="software.php">软件</a></li>
				<li><a href="magic.php">魔方</a></li>
				<li><a href="mixed.php">杂七杂八</a></li>
				</ul>
		</div>
	</div>
	<div class="body">
		<div class="explain">
			<p>	一时之间也想不到还加什么板块好，那目前就先这样，这里主要放些杂七杂八的思绪与看法。</p>
			<p style="color: #A8A8A8">（假装很深沉）</p>
		</div>
		 
		 <div class="log">

		 	<div class="cardBox">
		 		<p>
		 		<p style="text-align: center;font-size: 25px;margin-bottom: 0px;">日常份抱怨与瞎想</p>
				<p>这个网站诞生于我最忙的最近。</p>
				<p>说起来很有意思，最热衷于乒乓球的时候是小升初那段时间，到现在最满意的摄影作品大多拍摄于初三那段最压抑的时期，魔方玩得最6、免流研究得可以拿去卖的时期，正是高三。</p>
				<p>似乎压力最大的时候，总会把很多精力放在其他地方，而且还搞得不错。毕竟很分散精力，不算什么好事；但也不算太坏吧，好歹有所收获。</p>
				<p>现在也不例外，这是我大学以来，至今最忙的几周：四门不好学的专业课，每周两三篇实验报告，隔周一次的C++答辩，每周刷不完的学习通……本以为这学期有20个助理可以轻松些，结果还是焦头烂额，工作能力强的几个都因为加班好几个中午没睡……通篇的抱怨，或许我这是在逃避吧，想暂时地什么也不想去管，好好沉浸在自己的网站构建中。</p>
				<p>
					但至少，这次的建站对上了网络工程这个专业，无论以后是搞后端，前端，路由交换，都没坏处。
				</p>
				<p style="text-align: right;">2019-5-10</p>
		 		</p>
		 	</div>
		 </div>
	 	
	</div>

    
</body>

</html>